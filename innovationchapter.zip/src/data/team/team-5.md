---
#preview details
image: /images/team-4-1000x1357.jpg
name: Alexander Bravo
role: Full-Stack Developer
first_letter: A
social:
  - link: https://facebook.com/
    icon: fab fa-facebook-f
    title: Facebook

  - link: https://linkedin.com/
    icon: fab fa-linkedin-in
    title: Linkedin

#full details
info:
  - label: Age
    value: 26 Years
  
  - label: Location
    value: Baird House, 15-17 St Cross St London EC1N 8UW
  
  - label: Email
    value: alexander.bravo@domain.com

  - label: Phone No
    value: +44 (0) 20 7430 2973

services: 
  - service-1
  - service-2
  - service-3
  - service-4
  - service-5

awards:
  - label: 7 SOTD <br> 17 HONORABLE MENTION <br> 3 MOBILE EXCELLENCE
    value: 31
    image: /images/award1.png

  - label: 11 SOTD <br> 5 SPECIAL KUDOS
    value: 16
    image: /images/award2.png

  - label: AWARD 2019 <br> 1 GLOBAL COMPETITION
    value: 20
    image: /images/award3.png

projects: 
  - project-03
  - project-04
  - project-05
  - project-06
---

Our knowledgeable cost management experts understand the importance of delivering a project to meet your expectations in terms of cost, time, and quality. We will work with you to find the right, flexible and valuable solutions. No matter what sector you operate in, or the **scale of your project**, our team have the experience and know-how to support you with your goals.

The most exciting would be that no day is ever the same and each day brings new challenges. My professional passion would be team morale and relationship building. I think the true measure of success in an organization is to gage employee satisfaction, engagement nd the relationships that they build. I truly never envisioned that Construction would have been the organization that empowers. The most exciting would be that no day is ever the same and each day brings new challenges. My professional passion would be team morale and relationship building.

- Far curiosity incommode now led smallness allowance.
- Favour bed assure son things yet.
- She consisted consulted elsewhere happiness.
- Widow downs you new shade drift hopes small.
- Interested discretion estimating on stimulated.